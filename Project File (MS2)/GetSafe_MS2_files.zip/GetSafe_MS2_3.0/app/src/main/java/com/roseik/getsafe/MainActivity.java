package com.roseik.getsafe;


import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.roseik.getsafe.SimpleGestureFilter.SimpleGestureListener;
import com.roseik.getsafe.ui.login.LoginActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.telephony.emergency.EmergencyNumber;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements SimpleGestureListener{

    int sDirection = 0;
    FloatingActionButton nav_btn;
    Button profile_nav, settings_nav, emergency_nav, login_nav;
    ImageButton EBtn, dismiss;
    boolean emergBool = false;
    boolean cancelAction = false;

    private SimpleGestureFilter detector;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        detector = new SimpleGestureFilter(this,this);
        nav_btn =(FloatingActionButton) findViewById(R.id.navigation);
        dismiss =(ImageButton) findViewById(R.id.dismissBtn);
        profile_nav = (Button) findViewById(R.id.profile_nav);
        settings_nav = (Button) findViewById(R.id.settings_nav);
        emergency_nav = (Button) findViewById(R.id.emergency_nav);
        login_nav = (Button) findViewById(R.id.logout_nav);
        EBtn = (ImageButton) findViewById(R.id.imageButton);

        Rect dismissRect = new Rect(dismiss.getLeft(), dismiss.getTop(), dismiss.getRight(), dismiss.getBottom());

//        dismiss.setVisibility(View.INVISIBLE);
        profile_nav.setVisibility(View.INVISIBLE);
        settings_nav.setVisibility(View.INVISIBLE);
        emergency_nav.setVisibility(View.INVISIBLE);
        login_nav.setVisibility(View.INVISIBLE);


        EBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dismiss.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == android.view.MotionEvent.ACTION_DOWN ) {

                } else
                if(event.getAction() == android.view.MotionEvent.ACTION_UP){
                    //CANCEL ACTION
                    emergBool = false;
                    dismiss.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(),"Canceling action",Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });

        EBtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                Rect rect = new Rect(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());

//                if(event.getAction() == android.view.MotionEvent.ACTION_DOWN ) {
//
//
//                } else
                if(event.getAction() == android.view.MotionEvent.ACTION_UP){
                    if(!rect.contains(v.getLeft() + (int) event.getX(), v.getTop() + (int) event.getY())){
                        if (!dismissRect.contains(v.getLeft() + (int) event.getX(), v.getTop() + (int) event.getY()))
                            dismiss.setVisibility(View.INVISIBLE);
                        else
                            Toast.makeText(getApplicationContext(),"Canceling Action",Toast.LENGTH_LONG).show();

                    }else {
                        Toast.makeText(getApplicationContext(),"Running Emergency Action",Toast.LENGTH_LONG).show();
                        dismiss.setVisibility(View.INVISIBLE);
                    }
                }else
                if(event.getAction() == MotionEvent.ACTION_MOVE){
                    if(rect.contains(v.getLeft() + (int) event.getX(), v.getTop() + (int) event.getY())){
                            dismiss.setVisibility(View.VISIBLE);
                    }

                }
                return false;
            }
        });

        nav_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (profile_nav.getVisibility() == View.VISIBLE){
                    profile_nav.setVisibility(View.INVISIBLE);
                    settings_nav.setVisibility(View.INVISIBLE);
                    emergency_nav.setVisibility(View.INVISIBLE);
                    login_nav.setVisibility(View.INVISIBLE);
                }else {
                    profile_nav.setVisibility(View.VISIBLE);
                    settings_nav.setVisibility(View.VISIBLE);
                    emergency_nav.setVisibility(View.VISIBLE);
                    login_nav.setVisibility(View.VISIBLE);
                }
            }
        });


        profile_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), UserProfile.class);
                startActivity(i);

            }
        });
        settings_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Settings.class);
                startActivity(i);

            }
        });
        login_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("isFirstRun", true).apply();
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
            }
        });
//        emergency_nav.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(i);
//
//            }
//        });

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent me){
        // Call onTouchEvent of SimpleGestureFilter class
        this.detector.onTouchEvent(me);
        return super.dispatchTouchEvent(me);
    }
    @Override
    public void onSwipe(int direction) {


        switch (direction) {

            case SimpleGestureFilter.SWIPE_RIGHT : sDirection = 3;
                break;
            case SimpleGestureFilter.SWIPE_LEFT :  sDirection = 4;
                break;
            case SimpleGestureFilter.SWIPE_DOWN :  sDirection = 2;
                break;
            case SimpleGestureFilter.SWIPE_UP   :  sDirection = 1;
                break;

        }
//        switch (direction) {
//
//            case SimpleGestureFilter.SWIPE_RIGHT : str = "Swipe Right";
//                break;
//            case SimpleGestureFilter.SWIPE_LEFT :  str = "Swipe Left";
//                break;
//            case SimpleGestureFilter.SWIPE_DOWN :  str = "Swipe Down";
//                break;
//            case SimpleGestureFilter.SWIPE_UP :    if (emergBool){
//                dismiss.setVisibility(View.VISIBLE);
//            }else{
//                dismiss.setVisibility(View.INVISIBLE);
//            };
//                break;
//
//        }
        Toast.makeText(this, "DIR " + sDirection, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDoubleTap() {
        Toast.makeText(this, "Double Tap", Toast.LENGTH_SHORT).show();
    }


}