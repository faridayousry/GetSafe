package com.roseik.getsafe;


import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.roseik.getsafe.SimpleGestureFilter.SimpleGestureListener;
import com.roseik.getsafe.ui.login.LoginActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.emergency.EmergencyNumber;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements SimpleGestureListener{

    FloatingActionButton nav_btn, dismiss;
    Button profile_nav, settings_nav, emergency_nav, login_nav;
    ImageButton EBtn;
    boolean emergBool = false;
    boolean cancelAction = false;

    private SimpleGestureFilter detector;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        detector = new SimpleGestureFilter(this,this);
        nav_btn =(FloatingActionButton) findViewById(R.id.navigation);
        dismiss =(FloatingActionButton) findViewById(R.id.dismissBtn);
        profile_nav = (Button) findViewById(R.id.profile_nav);
        settings_nav = (Button) findViewById(R.id.settings_nav);
        emergency_nav = (Button) findViewById(R.id.emergency_nav);
        login_nav = (Button) findViewById(R.id.logout_nav);
        EBtn = (ImageButton) findViewById(R.id.imageButton);


//        dismiss.setVisibility(View.INVISIBLE);
        profile_nav.setVisibility(View.INVISIBLE);
        settings_nav.setVisibility(View.INVISIBLE);
        emergency_nav.setVisibility(View.INVISIBLE);
        login_nav.setVisibility(View.INVISIBLE);


        EBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dismiss.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == android.view.MotionEvent.ACTION_DOWN ) {
//                    Toast.makeText(getApplicationContext(),"down",Toast.LENGTH_LONG).show();
                } else
                if(event.getAction() == android.view.MotionEvent.ACTION_UP){
                    //CANCEL ACTION
                    emergBool = false;
                    dismiss.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(),"Canceling action",Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });

        EBtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == android.view.MotionEvent.ACTION_DOWN ) {
//                    Toast.makeText(getApplicationContext(),"down",Toast.LENGTH_LONG).show();
                    emergBool = true;
                } else
                if(event.getAction() == android.view.MotionEvent.ACTION_UP){

                    Toast.makeText(getApplicationContext(),"Running Emergency Action",Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });

        nav_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (profile_nav.getVisibility() == View.VISIBLE){
                    profile_nav.setVisibility(View.INVISIBLE);
                    settings_nav.setVisibility(View.INVISIBLE);
                    emergency_nav.setVisibility(View.INVISIBLE);
                    login_nav.setVisibility(View.INVISIBLE);
                }else {
                    profile_nav.setVisibility(View.VISIBLE);
                    settings_nav.setVisibility(View.VISIBLE);
                    emergency_nav.setVisibility(View.VISIBLE);
                    login_nav.setVisibility(View.VISIBLE);
                }
            }
        });


        profile_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), UserProfile.class);
                startActivity(i);

            }
        });
        settings_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Settings.class);
                startActivity(i);

            }
        });
        login_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("isFirstRun", true).apply();
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
            }
        });
//        emergency_nav.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(i);
//
//            }
//        });

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent me){
        // Call onTouchEvent of SimpleGestureFilter class
        this.detector.onTouchEvent(me);
        return super.dispatchTouchEvent(me);
    }
    @Override
    public void onSwipe(int direction) {
        String str = "";

        switch (direction) {

            case SimpleGestureFilter.SWIPE_RIGHT : str = "Swipe Right";
                break;
            case SimpleGestureFilter.SWIPE_LEFT :  str = "Swipe Left";
                break;
            case SimpleGestureFilter.SWIPE_DOWN :  str = "Swipe Down";
                break;
            case SimpleGestureFilter.SWIPE_UP :    if (emergBool){
                dismiss.setVisibility(View.VISIBLE);
            }else{
                dismiss.setVisibility(View.INVISIBLE);
            };
                break;

        }
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDoubleTap() {
        Toast.makeText(this, "Double Tap", Toast.LENGTH_SHORT).show();
    }


}