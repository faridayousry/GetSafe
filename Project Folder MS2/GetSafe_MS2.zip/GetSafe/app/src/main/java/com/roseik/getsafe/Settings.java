package com.roseik.getsafe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.roseik.getsafe.ui.login.LoginActivity;

public class Settings extends AppCompatActivity {

    FloatingActionButton nav_btn2;
    Button profile_nav2, settings_nav2, emergency_nav2, login_nav2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        nav_btn2 =(FloatingActionButton) findViewById(R.id.navi2);
        profile_nav2 = (Button) findViewById(R.id.profile_2);
        emergency_nav2 = (Button) findViewById(R.id.emergency_2);
        login_nav2 = (Button) findViewById(R.id.logout_2);
        settings_nav2 = (Button) findViewById(R.id.settings_2);



        nav_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (profile_nav2.getVisibility() == View.VISIBLE){
                    profile_nav2.setVisibility(View.INVISIBLE);
                    settings_nav2.setVisibility(View.INVISIBLE);
                    emergency_nav2.setVisibility(View.INVISIBLE);
                    login_nav2.setVisibility(View.INVISIBLE);
                }else {
                    profile_nav2.setVisibility(View.VISIBLE);
                    settings_nav2.setVisibility(View.VISIBLE);
                    emergency_nav2.setVisibility(View.VISIBLE);
                    login_nav2.setVisibility(View.VISIBLE);
                }
                }
        });


        profile_nav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), UserProfile.class);
                startActivity(i);

            }
        });
        login_nav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("isFirstRun", true).apply();
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);

            }
        });
        emergency_nav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);

            }
        });
    }
}